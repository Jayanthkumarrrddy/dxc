package org.animals;

public class Lion {
	String colour ="Tawny Yellow";
	float weight= (float) 165.5;
	int age = 12; 
	public void vegetarian() {
		
		System.out.println("Lion is not a vegetarian");
	}
	public void canClimb() {
		System.out.println("Lion can not climb ");
		
	}
	public void getSound() {
		System.out.println("Lion sounds lika a pro ");
		
	}
	public void liondetails() {
		System.out.println("-------Lion------- ");
		System.out.println("Lion Colour is:"+colour);
		System.out.println("Lion Weight in kg's is:"+weight);
		System.out.println("Lion Age in years is:"+age);
	}
		
}
