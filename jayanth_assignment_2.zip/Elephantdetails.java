package org.animals;

public class Elephant {
	String colour ="Grayish Black";
	float weight= (float) 3000;
	int age = 29; 
	public void vegetarian() {
		
		System.out.println("elephant is herbivorous");
	}
	public void canClimb() {
		System.out.println("elephant can not climb ");
		
	}
	public void getSound() {
		System.out.println("elephant sounds  ");
		
	}
	public void elephantdetails() {
		System.out.println("-------Elephant------- ");
		System.out.println("Elephant Colour is:"+colour);
		System.out.println("Elephant Weight is:"+weight);
		System.out.println("Elephant Age in Kg's is:"+age);
	}
	
}

